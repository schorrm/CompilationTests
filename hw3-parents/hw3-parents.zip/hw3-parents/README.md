# Tests for HW 3

This folder has the tests for HW 3 (plus the other stuff they gave). 
To get this for the first time, run `git clone https://github.com/schorrm/CompilationTests.git`.
Once you have it copied like that, to update, just go into the directory and run `git pull`. There'll probably be a whole bunch of updates with new edge cases and with much tougher tests as things get clarified.

Run `python3.6 tests.py` or `python3 tests.py` to run the test package (you'll need to move your files here). `python3 tests.py -v` will give the current version, and `python3 tests.py -h` will give usage.

If you want to work here, the .gitignore is set to ignore your specific files to keep the branch clean.

Good luck!

-Moshe Schorr
